from typing import Any, TypeVar
X = TypeVar('X') #Declare an arbitrary but same type below


def common_keys(d1: dict[X, Any], d2: dict[X, Any]) -> list[X]:
  """
  Consumes two dictionaries with the same key type and returns
  a list of all keys occuring in both dictionaries
  
  Examples:
     common_keys({}, {}) => []
     common_keys({}, {0:'zero', 1:'one'}) => []
     common_keys({0:'naught', 2:'deuce', 3: 'trey'},
                 {0:'zero', 1:'one'}) => [0]
  """
  return [key for key in d1 if key in d2]