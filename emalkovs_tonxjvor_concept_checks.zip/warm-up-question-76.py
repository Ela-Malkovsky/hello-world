def a_phobic(s: str) -> str:
  '''
  Returns s without 'a's and if the number of 'a's removed was even,
  we also append a '!' character.
  
  Examples:
     a_phobic("") => "!"
     a_phobic("bananab") => "bnnb"
  '''
  i = ""
  answer = 0
  
  for char in s: 
    if char != 'a':
      i += char
    else: 
      answer += 1
    
  if answer % 2 ==  0 and answer > 0:
    i += "!"
    
  return i