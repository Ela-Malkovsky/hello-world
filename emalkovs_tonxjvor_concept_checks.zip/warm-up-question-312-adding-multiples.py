import check

def sum_multiples(n: int, k: int) -> int:
  """
  Returns sum of all multiples of k <= n
  
  Requires: 0 < n, k
  
  Examples:
     sum_multiples(1, 1) => 1
     sum_multiples(14, 3) => 30
  """
  ##YOUR CODE GOES HERE
  total = 0 
  initial = k
  while initial <= n:
    total += initial
    initial += k 
  return total  

check.expect("Test 1", sum_multiples(1, 1), 1)
check.expect("Test 2", sum_multiples(14, 3), 30)