

def end_height(s: str) -> int:
  """
  Returns the last height starting from zero and going up for each 'u'
  character in s and down for every 'd' character in s.
  
  Requires:
     s consists of only 'u' and 'd' characters.
  
  Examples:
     end_height("") => 0
     end_height("uuuduu") => 4
     end_height("ddddud") => -4
     end_height("uuddu") => 1
  """
  ##YOUR CODE GOES HERE
  level = 0
  index = 0
  while index < len(s):
    if s[index] == 'u':
      level += 1
    elif s[index] == 'd':
      level -= 1
    
    index +=1
  
  return level
  
  