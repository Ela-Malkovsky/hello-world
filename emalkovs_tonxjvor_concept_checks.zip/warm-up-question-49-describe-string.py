def describe_string(s: str, c: str) -> int:
  """
  Returns the number of characters in s
  minus the non-negative index of the
  rightmost occurrence of c
  plus the number of c occurrences in the string.
  
  Requires: len(c) == 1
  
  Examples:
     describe_string("", 'c') => 1
     describe_string("banana", 'c') => 7
     describe_string("banana", 'a') => 4
  """
  ##YOUR CODE GOES HERE
  number_characters = len(s)
  rightmost_index = -1
  i = 0 
  while i < len(s): 
    if s[i] == c:
        rightmost_index = i 
    i += 1
    
  number_occur = 0 
  i = 0 
  while i <len(s):
    if s[i] == c:
      number_occur += 1
    i += 1
    
  if rightmost_index == -1:
    return number_characters + 1 + number_occur
    
  return number_characters - rightmost_index + number_occur
  
print(describe_string("", 'c'))
print(describe_string("banana", 'c'))
print(describe_string("banana", 'a'))
