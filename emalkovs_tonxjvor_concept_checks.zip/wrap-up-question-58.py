def first_digits(L: list[int]) -> None:
  """
  Mutates L so that each element is replaced by the first digit
  
  Effects: Mutates L
  
  Requires: L[i] > 0 for all indices i.
  
  Examples:
     If L is [] then
     first_digits(L) => None
     and L is unchanged
     
     If L is [31, 13] then
     first_digits(L) => None
     and L is mutated to [3, 1]
     
     If L is [1, 2, 3] then
     first_digits(L) => None
     and L is unchanged
  """
  for i in range(len(L)):
    L[i] = int(str(L[i])[0])