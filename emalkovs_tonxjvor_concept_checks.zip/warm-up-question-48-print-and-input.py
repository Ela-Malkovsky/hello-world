import check

def repeat() -> None:
  """
  Requests a string and an integer from keyboard
  and repeats the string the integer number of times
  and prints to the screen
  
  Effects:
     Prints to the screen
     Reads input from keyboard
  
  Examples:
     repeat() => None
     
     and abcabcabc is printed assuming the input given is
     abc
     3
     in that order.
  """
  x = input("Enter string: ")
  y = int(input("Enter positive integer: "))
  
  print(x * y)