def my_cat(x):
  if x < 10:
    if x < 5:  
      return "small"
    elif x > 5:
      return "very small"
  else:
    return "big"  
    