def nested_max(alol):
  '''
  Returns the largest value in alol
  
  nested_max: (listof (listof Int)) -> Int
  Requires: 
     alol is nonempty
     alol[0] is nonempty
  
  Examples:
     nested_max([[0], [1,2,3], [] ,[17,8,9,10]]) => 17
     nested_max([[1,5,3], [3],[35,1,2]]) =>  35
  '''
  answer = alol [0][0]
  for L in alol:
    for val in L:
      if val > answer:
        answer = val
  return answer