def my_count(s: str, char: str) -> int:
  '''
  Returns the number of occurrences of char in s
  without using the string or list method count.
  
  Requires:
     len(char) == 1
  
  Examples:
     my_count("", "c") => 0
     my_count("banana", "a") => 3
  '''
  return len([c for c in s if c == char])