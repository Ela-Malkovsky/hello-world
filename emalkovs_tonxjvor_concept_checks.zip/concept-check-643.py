def length_alphabetic_sort(los: list[str]) -> list[str]: 
  """
  Returns a new list so that the elements of los are sorted 
  in decreasing order of length with ties broken by 
  increasing alphabetic order
  
  Examples:
     length_alphabetic_sort([]) => []
     length_alphabetic_sort(['apple', 'banana', 'anana']) 
        => ['banana', 'anana', 'apple']
  """
  return sorted(los, key=lambda s: (-len(s), s))