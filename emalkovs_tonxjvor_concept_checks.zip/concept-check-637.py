def convert_to_letter_grade(lon: list[int]) -> list[str]:
  '''
  Returns a new list where each value in lon
  is replaced by a letter grade
  
  Requires: 0 <= L[i] <= 100 for each 0 <= i <= len(L)
  
  Examples:
     convert_to_letter_grade([]) => []
     convert_to_letter_grade([0]) => ['F']
     convert_to_letter_grade([49, 59, 69, 79, 89]) 
        => ['F', 'D', 'C', 'B', 'A']
  '''
  return list(map(lambda x: 
    'A' if 80 <= x <= 100 else 
    'B' if 70 <= x <= 79 else
    'C' if 60 <= x <= 69 else 
    'D' if 50 <= x <= 59 else
    'F', lon))