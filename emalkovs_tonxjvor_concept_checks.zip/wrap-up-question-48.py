def longest_string(t: tuple[str, ...]) -> str:
  """
  Returns the longest string
  
  Requires:
     len(t) > 0
  
  Examples:
     longest_string(("",)) => ""
     longest_string(("banana", "apple")) => "banana"
     longest_string(("banana", "apples")) => "banana"
  """
  ##YOUR CODE GOES HERE
  longest = "" 
  
  for s in t: 
    if len(s) > len(longest):
      longest = s
  return longest