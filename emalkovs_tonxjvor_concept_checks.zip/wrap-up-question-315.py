def name_change(old, new_last):
  """
  Changes the old string's last name to the string new_last
  
  name_change: Str Str -> Str
  Requires:
     old contains at least one space separating first
     and last name.
  
  Examples:
     name_change("John Doe", "Smith") => "John Smith"
     name_change("Bruce Thomas Wayne", "Willis") => "Bruce Thomas Willis"
  """
  i = len (old) -1
  while i >= 0 and old[i] != ' ':
    i -= 1
    
  return old[:i + 1] + new_last
  
print (name_change("John Doe", "Smith"))
print (name_change("Bruce Thomas Wayne", "Willis"))

  