def print_every_kth_char(k: int) -> None:
  '''
  Prints every kth character to the screen
  
  Effects:
     Prints to screen
  
  Requires: k > 0
  
  Examples:
     print_every_kth_char(1) => None
     and every character from a to z is printed on its own line
     
     print_every_kth_char(10) => None
     and the following is printed:
     a
     k
     u
  '''
  d = "abcdefghijklmnopqrstuvwxyz"
  for char in d[::k]:
    print(char)