import check

def largest_even_number(a: int, b: int, c: int) -> int:
  """
  Returns the largest even number of a, b or c
  or the smallest number if all are odd
  
  Examples:
     largest_even_number(2, 100, 4) => 100
     largest_even_number(2, 101, 41) => 2
     largest_even_number(-51, 101, 41) => -51
  """
  ##find smallest
  smallest = min (a, b, c)
  ##Initialize temp variable for largest number
  largest_even_number = None
  ## find largest 
  if a % 2 == 0:
    largest_even_number = a
  if b % 2 == 0 and (largest_even_number is None or b > largest_even_number):
    largest_even_number = b
  if c % 2 == 0 and (largest_even_number is None or c > largest_even_number):
    largest_even_number = c
  if largest_even_number is not None: 
    return largest_even_number
  else: 
    return smallest
  
    
check.expect("Test 1", largest_even_number(2, 100, 4), 100)      
check.expect("Test 2", largest_even_number(2, 101, 41), 2)       
check.expect("Test 3", largest_even_number(-51, 101, 41), -51)   