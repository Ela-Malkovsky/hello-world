def num_a(s: str) -> int:
  """
  Returns the number of 'a' characters in s
  """
  if s == "":
    return 0
    
  if s[0] == 'a':
    return 1 + num_a(s[1:])
  else:
    return num_a(s[1:])
