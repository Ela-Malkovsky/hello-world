def str_starters_list(L: list[str], s: str) -> int:
  """
  Returns the number of all elements in 
  L that start with s
  
  Examples: 
     str_starters_list([], '') => 0
     str_starters_list(['banana', 'bar', 
                  'blast', 'bag', 'apple', 'zoo'], 'ba') => 3
  """
  count = 0
  for val in L:
    if val[:len(s)] == s:
      count += 1
  return count  