def even_product(t: tuple[int, ...]) -> int:
  """
  Returns the product of all even numbers in t
  
  Examples:
     even_product(()) => 1
     even_product((11,)) => 1
     even_product((11,2)) => 2
     even_product((2, 3, 4, 5, 6, 7, 8)) => 384
  """
  ##YOUR CODE GOES HERE
  product = 1
  even_n = False
  
  for i in t: 
    if i % 2 == 0:
      product *= i
      even_n = True
      
  return product if even_n else 1 
  
pass