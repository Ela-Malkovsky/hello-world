def vowel_sort(los: list[str]) -> None:
  """
  Mutates the list los so that the elements are sorted in 
  increasing order of the number of vowels (either upper
  or lower case) in the string.
  
  Effects: Mutates los
  
  Examples:
     If L = [] then
     vowel_sort(L) => None
     and L is unchanged
  
     If L = ['aaa', 'adt', 'ab', 'aziubapiqulwerknii', 'eeeeee'] then
     vowel_sort(L) => None
     and L is mutated to ['adt', 'ab', 'aaa', 'eeeeee', 'aziubapiqulwerknii']
     
     If L = ['dog', 'cat', 'fish', 'yyz', 'tuna', 'elephant'] then
     vowel_sort(L) => None
     and L is mutated to ['yyz', 'dog', 'cat', 'fish', 'tuna', 'elephant']
  """
  def count_vowels(s: str) -> int:
    vowels = set("aeiouAEIOU")
    return sum(1 for char in s if char in vowels)
    
  los.sort(key=lambda s: (count_vowels(s)))