def concatenate(L: list[str]) -> str:
  """
  Returns the concatenation of all elements of L
  
  Examples:
     concatenate([]) => ''
     concatenate(['']) => ''
     concatenate(['b','a','n','a','n','a']) => 'banana'
  """
  answer = ""
  for element in L:
    answer += element 
    
  return answer