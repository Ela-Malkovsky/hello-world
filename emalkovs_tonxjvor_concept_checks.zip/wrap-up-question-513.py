def sum_odd_squares(L: list[int]) -> int:
  """
  Returns the sum of squares of all odd elements in L
  
  Examples:
     sum_odd_squares([]) => 0
     sum_odd_squares([1, 2, 3]) => 10
     sum_odd_squares([2, 4, 6, 8]) => 0
  """
  answer = 0 
  for val in L:
    if val % 2 != 0:
      answer += val ** 2
  return answer