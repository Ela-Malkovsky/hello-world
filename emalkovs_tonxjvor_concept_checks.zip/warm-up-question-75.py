def sums(lol: list[list[int]]) -> None:
  '''
  Mutates lol so that each element is replaced by 
  the sum of the inner list
  
  Effects: Mutates lol
    
  Examples: 
     If L = [] then
     sums(L) => None
     and L is unchanged
     
     If L = [[]] then
     sums(L) => None
     and L is mutated to [0]
     
     If L = [[1, 2], [], [7, 8, 9, 10]] then
     sums(L) => None
     and L is mutated to [3, 0, 34]
  '''    
  for i in range(len(lol)):
    lol[i] = sum(lol[i])