def is_palindrome(s: str) -> bool:
  """
  Returns True if s is a palindrome and False otherwise
  
  Examples:
     is_palindrome("") => True
     is_palindrome("banana") => False
     is_palindrome("radar") => True
  """
  return s == s[::-1]