def pig_latin(s: str) -> str:
  """
  Given a lower case Latin alphabet string s, return the 
  Pig Latin equivalent of the word.
  
  Requires:
     s contains only letters from the lower case Latin alphabet.
     s is nonempty.
  
  Examples:
     pig_latin('apple') => 'appleway'
     pig_latin('your') => 'ouryay'
     pig_latin('sun') => 'unsay'
  """
  vowels = 'aeiou' 
  if s[0] in vowels:
    return s + 'way'
  else: 
    return s[1:] + s[0] + 'ay'
  
print(pig_latin('apple'))
print(pig_latin('your'))
print(pig_latin('sun'))
  