def intersection(L: list, M: list) -> list:
  """
  Returns a list of common elements in L and M
  
  Requires: L and M do not contain duplicates
  
  Examples:
     intersection([1, 2, 3], []) => []
     intersection([1, 2, 3], [2, 99, 1]) => [1, 2]
  """
  answer = []
  for val in L:
    if val in M:
      answer.append(val)
  return answer