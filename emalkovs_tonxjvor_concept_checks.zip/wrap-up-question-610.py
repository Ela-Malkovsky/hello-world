def tuple_sort(L: list[tuple[int, int, int]]) \
                -> list[tuple[int, int, int]]:
  """
  Returns a new list of triples sorted by largest median value
  with ties broken by largest product.
  
  Examples:
     tuple_sort([]) => []
     tuple_sort([(1,2,3)]) => [(1,2,3)]
     tuple_sort([(1,2,3), (6,2,5)]) => [(6,2,5), (1,2,3)]
  """
  def median(t):
    sorted_t = sorted(t)
    return sorted_t[1]
    
  def answer(t):
    return t[0] * t[1] * t[2]
    
  return sorted(L, key=lambda t: (-median(t), -answer(t), L.index(t)))