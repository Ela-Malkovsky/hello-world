import math

def stirling(n: int) -> float:
  """
  Returns an approximation to n! according to Stirling's formula
  
  Requires: 
     0 < n
  
  Examples:
     stirling(1) => 0.9221370088957891
     stirling(4) => 23.506175132893294
  """
  ##Calculate Stirling's approximation
  approximation = math.sqrt(2*math.pi*n)*(n/math.e)**n
  return approximation