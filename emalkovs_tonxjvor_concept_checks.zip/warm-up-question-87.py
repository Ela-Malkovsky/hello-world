def collate(t: tuple[str]) -> tuple[str]:
  """
  Returns a tuple of strings where the answer at each index
  i is formed by using all the ith letters from strings of t

  Examples:
     collate(()) => ()
     collate(("a",)) => ("a",)
     collate(("tee", "ear", "ate")) => ("tea", "eat", "ere")
  """
  if not t:
    return ()
    
  return tuple(''.join(chars) for chars in (zip.*t))