def sum_columns(t):
  '''
  Returns a list consisting of the sum of all columns of Table t
  where Tables are (listof (listof Int)).
  
  sum_columns: Table -> (listof Int)
  
  Examples:
     sum_columns([[1]]) => [1]
     sum_columns([[1,2,3]]) => [1, 2, 3]
     sum_columns([[1],[2],[3]]) => [6]
     sum_columns([[1,2],[3,4],[5,6],[7,8]]) => [16, 20]
  '''
  return list (map(sum,zip(*t)))