def my_max(L: list[int|float]|list[str]) -> int|float|str:
  """
  Returns the maximum of L.

  Requires: L is non-empty
  
  Examples:
     my_max([1, 2.1, 3]) => 3
     my_max(['oranges', 'apples', 'pears', 'bananas']) => 'pears'
  """
  answer = L[0] 
  for i in L:
    if i > answer:
      answer = i
  return answer