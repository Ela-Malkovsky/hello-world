def record_digits(s: str) -> tuple[int, int, int, int, int,
                                   int, int, int, int, int]:
  '''
  Returns a list of 10 numbers corresponding to the 
  number of occurrences of each digit in the string s
  
  Examples:
     record_digits("") => (0, 0, 0, 0, 0, 
                           0, 0, 0, 0, 0)
     record_digits("banana") => (0, 0, 0, 0, 0, 
                                 0, 0, 0, 0, 0)
     record_digits("34298465fsdf3") => (0, 0, 1, 2, 2, 
                                        1, 1, 0, 1, 1)
  '''
  L = [0] *10
  
  L = tuple(sum(1 for x in s if x == str(i)) for i in range (10))
  
  return L