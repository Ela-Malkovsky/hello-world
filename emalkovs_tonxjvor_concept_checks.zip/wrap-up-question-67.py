def add_a(L: list[str]):
  '''
  Returns a new list consisting of all strings in L that begin with 
  the letter a.  Elements should be returned respecting their 
  relative order in L.
  
  Examples:
     add_a([]) => []
     add_a(["apricot", "apple", "banana", "avocado"]) 
       =>  ["apricot", "apple", "avocado"])
  '''
  return [i for i in L if len(i) > 0 and i[0] =='a'] 