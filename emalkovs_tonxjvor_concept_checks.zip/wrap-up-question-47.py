def find_all_subs(s: str, sub: str) -> tuple[int, ...]:
  """
  Returns a list of positions in s where sub can be found.

  Requires:
     sub != ''
  
  Examples:
     find_all_subs("", "a") => ()
     find_all_subs("aaa", "a") => (0, 1, 2)
     find_all_subs("banana", "an") => (1, 3)
  """
  ##YOUR CODE GOES HERE
  pos = ()
  i = 0
  sub_length = len(sub)
  
  while i <= len(s) - sub_length:
    if s [i:i + sub_length] == sub: 
      pos += (i,)
    i += 1
    
  return pos