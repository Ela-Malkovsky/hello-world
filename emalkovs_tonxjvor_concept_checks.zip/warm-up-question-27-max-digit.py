def max_digit(n: int) -> int:
  """
  Returns the largest digit of the two digit number n
  
  Requires: 10 <= n <= 99
  
  Examples:
     max_digit(10) => 1
     max_digit(99) => 9
  """
  #seperate tens and ones 
  tens = n // 10
  ones= n % 10
  #calculate max digit in number
  max_digit = max (tens, ones)
  return max_digit