import check

def champernowne_constant(n: int) -> str:
  """
  Returns Chapernowne's Constant up to and include n
  as a string "0.1234567891011....n"
  
  Requires: n >= 1
  
  Examples:
     champernowne_constant(1) => "0.1"
     champernowne_constant(12) => "0.123456789101112"
  """
  #YOUR CODE GOES HERE
  answer = "0." 
  i = 1 
  while i <= n:
    answer += str(i)
    i += 1
  return answer

check.expect("Test 1", champernowne_constant(1), "0.1")
check.expect("Test 12", champernowne_constant(12), "0.123456789101112")
