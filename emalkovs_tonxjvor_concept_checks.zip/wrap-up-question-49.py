def count_ending(t: tuple[int, ...], digit: int) -> int:
  """
  Returns the number of values in t
  that end with digit
  
  Requires: 0 <= digit <= 9
  
  Examples:
     count_ending((), 3) => 0
     count_ending((13,), 3) => 1
     count_ending((13, 11, 51, 12, 66, 64, 35, 7, 99999999), 1) => 2
  """
  pos = 0
  answer = 0
  
  while pos < len(t):
    if t[pos] % 10 == digit:
        answer += 1
    pos += 1
  
  return answer  

  
  