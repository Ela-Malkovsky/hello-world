import math

def euler(n: int) -> int:
  """
  Returns phi(n)
  
  Requires: 0 < n
  
  Examples:
     euler(1) => 1
     euler(6) => 2
     euler(7) => 6
     euler(10) => 4
  """
  count = 0
  d = 1
  
  while d <= n:
    if math.gcd(d,n) == 1:
      count += 1
    d += 1
  
  return count