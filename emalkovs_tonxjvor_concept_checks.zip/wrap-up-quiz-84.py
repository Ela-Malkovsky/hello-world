from typing import Any

class Movie:
  name: str
  year: int
  rating: int

  def __init__(self, n: str, y: int, r: int) -> None:
    """
    Constructor: Create a Movie object by 
    calling Movie(n, y, r)
      
    Effects: Mutates Self
    Requires:
      y > 0
      0 <= r <= 10
    """
    self.name = n
    self.year = y
    self.rating = r
    
  def __eq__(self, other: Any) -> bool:
    """
    Returns True if the movies are equal
    and False otherwise
    """
    if type(other) is not Movie:
      return False
    
    movie_self = (self.name, self.year, self.rating)
    movie_other = (other.name, other.year, other.rating)
    
    return movie_self == movie_other