##COPY THE ENTIRE 5 LINES OF CODE ABOVE HERE AND SUBMIT!
import check

def echo():
  n = input("Enter a value:")
  print(n)
    
check.set_input("Hi") 
check.expect("Test 1", echo(), None)