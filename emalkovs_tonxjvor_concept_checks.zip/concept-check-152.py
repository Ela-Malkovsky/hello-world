import math

def cosine_law(a: float, b: float, theta: float) -> float:
  """
  Returns the third side length using 
  the cosine law with side lengths a and b 
  and contained angle theta in radians
  
  cosine_law: Float Float Float -> Float
  Requires:
     0.0 < a
     0.0 < b
     0.0 < theta < math.pi
     
  Example:
     cosine_law(3, 4, math.pi/3) => 3.60555127546
  """
  ## calculate third side using cosine law
  third_side = math.sqrt(a**2 + b**2 - 2*a*b*math.cos(theta))
  return third_side