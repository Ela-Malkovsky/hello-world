def sum_triples() -> None:
  """
  Consumes 3 integer inputs from keyboard
  and prints the sum of the three integers
  
  Effects:
     Prints to screen
     Reads input from keyboard
  
  Examples:
     If we call
     sum_triples() => None
     and give integers 1, 2, 3 as input,
     we print "6" to the screen (no quotes)
  """
  ##YOUR CODE GOES HERE
  n1 = int(input ("First option: "))
  n2 = int(input ("Second option: "))
  n3 = int(input ("Third option: "))

  total = n1 + n2 + n3
  print(total)
