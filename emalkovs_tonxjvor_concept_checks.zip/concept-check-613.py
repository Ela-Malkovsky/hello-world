def almost_equal(S: set[int], T: set[int]) -> bool:
  """
  Returns True if S and T are almost equal and False otherwise
  
  Examples:
     almost_equal(set(), set()) => True
     almost_equal({1}, set()) => False
     almost_equal({2, 4, 6, 8}, {7, 5, 3}) => True
  """
  answer = S.union(T)
  for i in answer:
    if not any(abs(i - j) <= 1 for j in answer if i != j):
      return False
      
  return True