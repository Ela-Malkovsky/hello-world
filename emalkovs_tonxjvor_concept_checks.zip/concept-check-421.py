def tuple_score(t: tuple) -> int:
  '''
  Returns the score of t where strings count as 1 point,
  integers count as their value and other types are worth 0.
  
  Examples:
     tuple_score(()) => 0
     tuple_score(("1", 1, True, (1,2,3))) => 2
     tuple_score(("bigword!!!", 99)) => 100
  '''
  score = 0 
  i = 0
  while i < len(t):
    item = t[i]
    if type(item) == str:
      score += 1
    elif type(item) == int:
      score += item
    else: 
      score += 0
    i += 1
    
    return score
  
print(tuple_score(()))
print(tuple_score(("1", 1, True, (1,2,3)))) 
print(tuple_score(("bigword!!!", 99)))      