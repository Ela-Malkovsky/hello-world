def rev_strings(los: list[str]) -> None:
  """
  Mutates los by reversing every element of los 
  in place and returns None
  
  Effects: Mutates los
  
  Examples:
     L = []
     rev_strings(L) => None
     and L is unchanged
     
     L = ['a', 'abc']
     rev_strings(L) => None
     and L is mutated to ['a', 'cba']
  """
  for i in range (len(los)):
    los[i] = los[i][::-1]