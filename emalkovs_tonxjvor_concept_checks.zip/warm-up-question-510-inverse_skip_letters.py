def inverse_skip_letters(s: str, k: int) -> str:
  """
  Returns a string with every kth letter 
  of s removed
  
  Requires: k > 0
  
  Examples:
     inverse_skip_letters("", 3) => ""
     inverse_skip_letters("a", 3) => ""
     inverse_skip_letters("banana", 2) => "aaa"
  """
  answer = "" 
  for i in range(len(s)):
    if (i + 1) % k == 0:
      answer += s[i]
  return answer