def sum_lasts(lol: list[list[int]]) -> int:
  """
  Returns the sum of all the last values 
  in the nonempty lists in lol
    
  Examples: 
     sum_lasts([]) => 0
     sum_lasts([[]]) => 0
     sum_lasts([[1,2],[],[7,8,9]]) => 11
  """
  sum_last_elements = 0
  for L in lol:
    if L != []:
      sum_last_elements += L[-1]
  return sum_last_elements