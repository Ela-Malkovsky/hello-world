def equinumerous(s: str) -> bool:
  '''
  Returns True if s is equinumerous and False otherwise.
  
  Examples:
     equinumerous("0") => False
     equinumerous("1010") => True
  '''
  count = {'0': 0, '1': 0}
  
  for char in s:
    if char in count:
      count[char] +=1
      
  return count['0'] == count['1']