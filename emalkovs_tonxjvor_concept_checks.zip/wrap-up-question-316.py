import check

def analyze_string(s: str) -> None:
  """
  Prints to the screen:
  contains C characters, P spaces, and ends with 'E'.
  (including the period above) where:
  C is the length of s, 
  P is the number of spaces (' ') in s
  E is the last character in s.
  
  Effects:
     Prints to screen
  
  Examples:
     analyze_string("") => None
     and prints
     contains 0 characters, 0 spaces, and ends with ''.
  
     analyze_string("Bananas are ripe!") => None
     and prints
     contains 17 characters, 2 spaces, and ends with '!'.
  """
  number_characters = len(s)
  number_spaces = 0
  i = 0 
  while i < number_characters:
    if s[i] == ' ':
      number_spaces += 1
    i += 1
  
  last_character = s [-1] if s else ''
  last_character = "'" + last_character + "'"
  
  print("contains " + str(number_characters) + str(number_spaces) + " spaces, and ends with '" + last_character + "'.")
  