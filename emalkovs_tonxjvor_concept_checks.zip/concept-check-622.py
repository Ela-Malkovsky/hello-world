import check


##Copied from above
def character_count(sentence: str) -> dict[str, int]:
  """
  Returns a dictionary that consists of a character
  and count of each character in the string sentence.
  
  Examples:
     character_count("") => {}
     character_count("banana") => {'a':3, 'b': 1, 'n':2}
  """
  characters = {}
  for char in sentence:
    characters[char] = characters.get(char, 0) + 1
  return characters
    
## Next, find the most common character in a string
def most_common_character(sentence: str) -> list[str]:
  """
  Returns the most common character in the string sentence.
  If there is a tie, returns the most common characters
  in the order they first appear in sentence.
   
  Requires: 0 < len(sentence)
     
  Examples: 
    most_common_character("c") => ["c"]
    most_common_character("banana") => ["a"]
    most_common_character("xbananaxx") => ["x", "a"]
  """

  ##EDIT THE CODE BELOW
  chars = character_count(sentence)
  most_common = []
  max_times = max(chars.values())
  for char in sentence:  
    if chars[char] == max_times and char not in most_common:
      most_common.append(char)

  return most_common