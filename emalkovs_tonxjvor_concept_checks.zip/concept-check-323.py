#use but do not import the check module
check.expect("Test 1", swap_two("ab", 0, 1), "ba")
check.expect("Test 2", swap_two("banana", 2, 5), "baaann")
