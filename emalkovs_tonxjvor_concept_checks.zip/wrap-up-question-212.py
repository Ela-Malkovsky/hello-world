import check

def sum_powers(b: int, n: int) -> int:
  """
  Returns 1 + b + ... + b^n
  
  Requires: n >= 0
  
  Examples:
     sum_powers(0, 0) => 1
     sum_powers(0, 100) => 1
     sum_powers(2, 3) => 15
  """
  #YOUR CODE GOES HERE
  answer = 0
  initializing_power = 1
  while n >= 0: 
    answer +=  initializing_power
    initializing_power *= b
    n -= 1
  return answer

check.expect ("Test Zero Power", sum_powers(0, 0), 1)
check.expect ("Test Large Power", sum_powers(0, 100), 1)
check.expect ("Test Two Power", sum_powers(2, 3), 15)

