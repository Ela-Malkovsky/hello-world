import check

def swap_two(s: str, pos1: int, pos2: int) -> str:
  """
  Returns s with s[pos1] and s[pos2] swapped.
  
  Requires:
     len(s) >= 2
     0 <= pos1 <= len(s) - 1
     0 <= pos2 <= len(s) - 1
  
  Examples:
     swap_two("ab", 0, 1) => "ba"
     swap_two("banana", 2, 5) => "baaann"
  """
  ##YOUR CODE GOES HERE
  if pos1 == pos2:
    return s
    
  if pos1 > pos2:
    pos1, pos2 = pos2, pos1
  
  return s[:pos1] + s[pos2] + s[pos1 + 1:pos2] + s[pos1] + s[pos2 + 1:]
  
check.expect("Test 1", swap_two("ab", 0, 1), "ba")
check.expect("Test 2", swap_two("banana", 2, 5), "baaann")
check.expect("Test 3", swap_two("hello", 1, 3), "hlleo")
check.expect("Test 4", swap_two("abcdef", 0, 5), "fbcdea")
check.expect("Test 5", swap_two("abcde", 2, 2), "abcde")

print("Tests passed!")