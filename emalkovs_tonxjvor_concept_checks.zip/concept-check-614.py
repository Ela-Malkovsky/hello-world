def is_distinct(L: list) -> bool:
  """
  Returns True if elements in L are distinct and 
  False otherwise.
  
  Requires: Elements in L are immutable.
  
  Examples:
     is_distinct([]) => True
     is_distinct([1, 1, 3]) => False
  """
  return len(L) == len(set(L))