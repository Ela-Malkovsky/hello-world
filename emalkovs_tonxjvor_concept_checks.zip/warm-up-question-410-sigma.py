def sigma(n: int) -> int:
  """
  Returns sum of all positive integer divisors of n
  
  Requires: 0 < n
  
  Examples:
     sigma(1) => 1
     sigma(6) => 12
  """
  ##YOUR CODE GOES HERE
  sum_n = 0 
  i = 1
  while i <= n:
    if n % i == 0:
      sum_n += i
    i += 1
  return sum_n

print(sigma(1))
print(sigma(6))  
